package com.exampledemo.parsaniahardik.drawerbasicdemonuts;

/**
 * Created by Parsania Hardik on 01-May-17.
 */
public class DrawerModel {

    private String name;
    private int image;

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
